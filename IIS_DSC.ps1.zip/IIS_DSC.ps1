Configuration IIS-WebSite
{
  param(
    [Parameter(Mandatory = $True)]
    [string[]]$MachineName,

    [Parameter(Mandatory = $True)]
    [string[]]$RolesAndFeatures
  )

  Node $MachineName
  { 
    #Install IIS
    xWindowsFeature IIS
    {
      Name = "Web-Server"
      Ensure = 'Present'
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = "Present"
      Name = "Web-Asp-Net45"
    }

    WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }
  }
} 