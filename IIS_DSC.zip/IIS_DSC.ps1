Configuration IIS-WebSite
{
  param(
    [Parameter(Mandatory = $True)]
    [string[]]$MachineName
  )

  Node $MachineName
  { 
    #Install IIS
    WindowsFeature IIS
    {
      Name = "Web-Server"
      Ensure = 'Present'
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = "Present"
      Name = "Web-Asp-Net45"
    }

    WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }
  }
} 